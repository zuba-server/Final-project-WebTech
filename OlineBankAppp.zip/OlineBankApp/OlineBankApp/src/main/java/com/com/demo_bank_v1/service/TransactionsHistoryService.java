//package com.com.demo_bank_v1.service;
//
//import com.com.demo_bank_v1.models.TransactionHistory;
//
//import java.util.List;
//
//public interface TransactionsHistoryService {
//    List<TransactionHistory> getAllTransactions();
//}
