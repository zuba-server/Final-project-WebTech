package com.com.demo_bank_v1.rest_controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/transact")
public class RestTransactApiController {


}
